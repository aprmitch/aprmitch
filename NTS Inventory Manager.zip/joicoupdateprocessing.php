<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Joico Inventory Update Processing</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<strong><h2>Joico Inventory Updated</h2></strong>
					
					</header>
					
					<div class="box">
					<table>
			
			<strong><tr><th>Body Luxe Cond.</th><th>Body Luxe Sh.</th><th>Color Endure Cond.</th><th>Color Endure Sh.</th><th>Color Endure Violet Cond.</th><th>Color Endure Violet Sh.</th></tr></strong>
					<?php
	//1. Connect to database: mysqli_connect()
	$host="localhost";
	$dbUsername="MIS4153";
	$dbPassword="pirates4thewin";
	$dbName="teamtrilogy";
	
	$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
	if(mysqli_connect_errno()){
	printf("Connect failed: %\n", mysqli_connect_error());
	} else {
	
	
	//2. Send query to database: mysqli_query()
	$sql = "SELECT * FROM joicoproducts ORDER BY ID DESC LIMIT 1";
	$JoicoArray = mysqli_query($connection, $sql);
	
	
			//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
			while ($joicoproducts=mysqli_fetch_assoc($JoicoArray)){
				echo "<tr>";
				echo "<td>". $joicoproducts["BodyLuxCond"] . "</td>";
				echo "<td>". $joicoproducts["BodyLuxSh"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndCond"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndSh"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndViCond"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndViSh"] . "</td>";
				
				echo "</tr>";
			}
			
	
				//4. Release returned data: mysqli_free_result()
			mysqli_free_result($JoicoArray);
	}
					//5. Close database connection: mysqli_close()
					mysqli_close($connection);
			
					?>
				</table>	
						<?php
									
							$BodyLuxCond=$_POST["BodyLuxCond"];
							$BodyLuxSh=$_POST["BodyLuxSh"];
							$ColorEndCond=$_POST["ColorEndCond"];
							$ColorEndSh=$_POST["ColorEndSh"];
							$ColorEndViCond=$_POST["ColorEndViCond"];
							$ColorEndViSh=$_POST["ColorEndViSh"];
											//1. Connect to database
									$host="localhost";
									$dbUsername="MIS4153";
									$dbPassword="pirates4thewin";
									$dbName="teamtrilogy";
						
									$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
									if(mysqli_connect_errno()){
										printf("Connect failed: %\n", mysqli_connect_error());
									} else {

					//2. Send query to database: mysqli_query()
					$sql = "Update joicoproducts SET BodyLuxCond='$BodyLuxCond', BodyLuxSh='$BodyLuxSh', ColorEndCond='$ColorEndCond', ColorEndSh='$ColorEndSh', ColorEndViCond='$ColorEndViCond', ColorEndViSh='$ColorEndViSh'";
					//echo $sql;
					$vendoraddressesArray = mysqli_query($connection, $sql);
					$lastID =mysqli_insert_id($connection);
					
					

					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
					
					
					?>	

					
				
					<div align="center">
					<br><br>	<strong><h1>What would you like to do next?</h1><strong>
					
					<a href="addinventory.php" class="button">Add Inventory</a><br>
							<br><a href="joicoinventory.php" class="button">View Joico Inventory</a><br>
			
				
					
							
				</div>
					
				
				
				</div>	
					
					
						
					</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>