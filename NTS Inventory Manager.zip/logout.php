<?php
	session_start();
		echo $_SESSION["username"];
			unset($_SESSION["username"]);
?>



<!DOCTYPE HTML>

<html>
	<head>
		<title>Good Bye
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Nikki Taylor Salon Inventory Manager</h1>
					<nav id="nav">
						<ul>
						<ul>
							<li><a href="index.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
			
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<h2>Logout Successful</h2>
					
					
					</header>
					
					<div class="box">
						<h3>Thank you and have a great day!</h3>
						Please log back in <a href="index.php">here</a>.
					
					</div>
				</section>

			<!-- Footer -->
			

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>