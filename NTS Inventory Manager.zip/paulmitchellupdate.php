<?php
session_start();
?>


<!DOCTYPE HTML>

<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Update Paul Mitchell Inventory</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
			
					<section id="main" class="container" align="center">
					<header>
						<h2>Current Paul Mitchell Inventory</h2>
					
					</header>
					
					<div class="box">
					<form method="POST" action="pmupdateprocessing.php">
					<table>
			
			<tr><th>Awapuhi Shampoo</th><th>Shampoo 1</th><th>Shampoo 2</th><th>Shampoo 3</th><th>The Conditioner</th></tr>
							<?php
			//1. Connect to database: mysqli_connect()
			$host="localhost";
			$dbUsername="MIS4153";
			$dbPassword="pirates4thewin";
			$dbName="teamtrilogy";
			
			$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
			if(mysqli_connect_errno()){
			printf("Connect failed: %\n", mysqli_connect_error());
			} else {
			
			
			//2. Send query to database: mysqli_query()
			$sql = "SELECT * FROM paulmitchell ORDER BY ID DESC LIMIT 1";
			$PaulMitchellArray = mysqli_query($connection, $sql);
			
			
					//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
					while ($paulmitchell=mysqli_fetch_assoc($PaulMitchellArray)){
						echo "<tr>";
						echo "<td>". $paulmitchell["AwapuhiSh"] . "</td>";
						echo "<td>". $paulmitchell["ShOne"] . "</td>";
						echo "<td>". $paulmitchell["ShTwo"] . "</td>";
						echo "<td>". $paulmitchell["ShThree"] . "</td>";
						echo "<td>". $paulmitchell["TheCond"] . "</td>";
						
						
						
						echo "</tr>";
					}
					
			
						//4. Release returned data: mysqli_free_result()
					mysqli_free_result($PaulMitchellArray);
			}
							//5. Close database connection: mysqli_close()
							mysqli_close($connection);
					
							?>
						</table>	
						<h2>Update Product Quantities Below</h2>
						<?php

//1. Connect to database: mysqli_connect()
$host="localhost";
$dbUsername="MIS4153";
$dbPassword="pirates4thewin";
$dbName="teamtrilogy";

$connection = mysqli_connect($host,$dbUsername,$dbPassword,$dbName);
if(mysqli_connect_errno()){
printf("Connect failed: %\n", mysqli_connect_error());
} else {


//2. Send query to database: mysqli_query()
$sql = "SELECT * FROM paulmitchell WHERE ID='" . $_GET["ID"] . "'";
$OlaplexArray = mysqli_query($connection, $sql);


//3. Use the returned data

$paulmitchell=mysqli_fetch_assoc($PaulMitchellArray);

echo "<br>Paul Mitchell Awapuhi: <input type='number' min=0 max=12 name='AwapuhiSh' value='" . $paulmitchell["AwapuhiSh"] . "'><br>";
echo "<br>Paul Mitchell Shampoo 1: <input type='number' min=0 max=12 name='ShOne' value='" . $paulmitchell["ShOne"] . "'><br>";
echo "<br>Paul Mitchell Shampoo 2: <input type='number' min=0 max=12 name='ShTwo' value='" . $paulmitchell["ShTwo"] . "'><br>";
echo "<br>Paul Mitchell Shampoo 3: <input type='number' min=0 max=12 name='ShThree' value='" . $paulmitchell["ShThree"] . "'><br>";
echo "<br>Paul Mitchell The Conditioner: <input type='number' min=0 max=12 name='TheCond' value='" . $paulmitchell["TheCond"] . "'><br>";

echo "<br><input type='hidden' name='ID' value='" . $_GET['ID'] . "'>";


//4. Release the returned data
mysqli_free_result($PaulMitchellArray);
}

//5. Close the connection
mysqli_close($connection);

?>	
<input type="submit" name="submit" value="Submit">

						</form>	
					
						
					</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>