<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>CosmoProf Inventory List</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<h2><strong>Paul Mitchell Inventory</strong></h2>
					
					</header>
					
					<div class="box">
						
						<?php
									
									$AwapuhiSh=$_POST["AwapuhiSh"];
									$ShOne=$_POST["ShOne"];
									$ShTwo=$_POST["ShTwo"];
									$ShThree=$_POST["ShThree"];
									$TheCond=$_POST["TheCond"];

									//1. Connect to database
									$host="localhost";
									$dbUsername="MIS4153";
									$dbPassword="pirates4thewin";
									$dbName="teamtrilogy";
						
									$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
									if(mysqli_connect_errno()){
										printf("Connect failed: %\n", mysqli_connect_error());
									} else {

					//2. Send query to database: mysqli_query()
					$sql = "Update paulmitchell SET AwapuhiSh='$AwapuhiSh', ShOne='$ShOne', ShTwo='$ShTwo', ShThree='$ShThree', TheCond='$TheCond'";
					//echo $sql;
					$PaulMitchellArray = mysqli_query($connection, $sql);
					$lastID =mysqli_insert_id($connection);
					
					

					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
					
					
					?>	
							<table>
			
			<tr><th>Awapuhi Shampoo</th><th>Shampoo 1</th><th>Shampoo 2</th><th>Shampoo 3</th><th>The Conditioner</th></tr>
							<?php
			//1. Connect to database: mysqli_connect()
			$host="localhost";
			$dbUsername="MIS4153";
			$dbPassword="pirates4thewin";
			$dbName="teamtrilogy";
			
			$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
			if(mysqli_connect_errno()){
			printf("Connect failed: %\n", mysqli_connect_error());
			} else {
			
			
			//2. Send query to database: mysqli_query()
			$sql = "SELECT * FROM paulmitchell ORDER BY ID DESC LIMIT 1";
			$PaulMitchellArray = mysqli_query($connection, $sql);
			
			
					//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
					while ($paulmitchell=mysqli_fetch_assoc($PaulMitchellArray)){
						echo "<tr>";
						echo "<td>". $paulmitchell["AwapuhiSh"] . " out of <strong>6</strong></td>";
						echo "<td>". $paulmitchell["ShOne"] . " out of <strong>8</strong></td>";
						echo "<td>". $paulmitchell["ShTwo"] . " out of <strong>8</strong></td>";
						echo "<td>". $paulmitchell["ShThree"] . " out of <strong>4</strong></td>";
						echo "<td>". $paulmitchell["TheCond"] . " out of <strong>6</strong></td>";
						
						
						
						echo "</tr>";
					}
					
			
						//4. Release returned data: mysqli_free_result()
					mysqli_free_result($PaulMitchellArray);
			}
							//5. Close database connection: mysqli_close()
							mysqli_close($connection);
					
							?>
						</table>
				
						<section id="main" class="container" align="center">
	<header>
		<h2><strong>Joico Inventory</strong></h2>

	</header>
	
	<br><div class="box">
		
		
	<table align="left">
			
			<strong><tr><th>Body Luxe Cond.</th><th>Body Luxe Sh.</th><th>Color Endure Cond.</th><th>Color Endure Sh.</th><th>Color Endure Violet Cond.</th><th>Color Endure Violet Sh.</th></tr></strong>
					<?php
	//1. Connect to database: mysqli_connect()
	$host="localhost";
	$dbUsername="MIS4153";
	$dbPassword="pirates4thewin";
	$dbName="teamtrilogy";
	
	$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
	if(mysqli_connect_errno()){
	printf("Connect failed: %\n", mysqli_connect_error());
	} else {
	
	
	//2. Send query to database: mysqli_query()
	$sql = "SELECT * FROM joicoproducts ORDER BY ID DESC LIMIT 1";
	$JoicoArray = mysqli_query($connection, $sql);
	
	
			//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
			while ($joicoproducts=mysqli_fetch_assoc($JoicoArray)){
				echo "<tr>";
				echo "<td>". $joicoproducts["BodyLuxCond"] . " out of <strong>8</strong></td>";
				echo "<td>". $joicoproducts["BodyLuxSh"] . " out of <strong>8</strong></td>";
				echo "<td>". $joicoproducts["ColorEndCond"] . " out of <strong>8</strong></td>";
				echo "<td>". $joicoproducts["ColorEndSh"] . " out of <strong>8</strong></td>";
				echo "<td>". $joicoproducts["ColorEndViCond"] . " out of <strong>8</strong></td>";
				echo "<td>". $joicoproducts["ColorEndViSh"] . " out of <strong>8</strong></td>";
				
				echo "</tr>";
			}
			
	
				//4. Release returned data: mysqli_free_result()
			mysqli_free_result($JoicoArray);
	}
					//5. Close database connection: mysqli_close()
					mysqli_close($connection);
			
					?>
				</table><br>
	</div>	
			</div>
				</section>
				<div align="center">
				<h3>***Please place order to replinish desired quantities***<h3>
</div>
			<!-- Footer -->
		
		 


		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>