<?php
session_start();
?>

<!DOCTYPE HTML>
<!--
	Twenty by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Add Joico Inventory</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="right-sidebar is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1 id="logo">Add New Joico Inventory</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<article id="main">

				<div class="box" align="center">
				<h2>Input <strong>Joico</strong> Product Quantities Below</h2>
					<form method="POST" action="JoicoAddProcessing.php">
						
						Body Luxe Conditioner: <p><input type="number" min=0 max=12 name="BodyLuxCond"></p><br>
						Body Luxe Shampoo: <p><input type="number" min=0 max=12 name="BodyLuxSh"></p><br>
						Color Endure Conditioner: <p><input type="number" min=0 max=12 name="ColorEndCond"></p><br>
						Color Endure Shampoo: <p><input type="number" min=0 max=12 name="ColorEndSh"></p><br>
						Color Endure Violet Conditioner: <p><input type="number" min=0 max=12 name="ColorEndViCond"></p><br>
						Color Endure Violet Shampoo: <p><input type="number" min=0 max=12 name="ColorEndViSh"></p><br>
				
					
						<br><input type="Submit" name="Submit" value="Submit">
						
						
						</form>	
						

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>