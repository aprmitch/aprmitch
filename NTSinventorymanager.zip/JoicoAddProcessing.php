<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>Joico Inventory Update
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Joico Inventory Update</h1>
					<nav id="nav">
						<ul>
						<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
			
						</ul>
					</nav>
				</header>
				
			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<strong><h2>Joico Inventory Added</h2></strong>
					
					</header>
					
					<div class="box">
					
						<?php
							$BodyLuxCond=$_POST["BodyLuxCond"];
							$BodyLuxSh=$_POST["BodyLuxSh"];
							$ColorEndCond=$_POST["ColorEndCond"];
							$ColorEndSh=$_POST["ColorEndSh"];
							$ColorEndViCond=$_POST["ColorEndViCond"];
							$ColorEndViSh=$_POST["ColorEndViSh"];
						
							echo "You added the following Joico products to inventory: ";
							
							echo "<li>$BodyLuxCond - Body Luxe Conditioner</li>";
							echo"<li>$BodyLuxSh - Body Luxe Shampoo</li>";
							echo"<li>$ColorEndCond - Color Endure Conditioner</li>";
							echo"<li>$ColorEndSh - Color Endure Shampoo</li>";
							echo"<li>$ColorEndViCond - Color Endure Violet Conditioner</li>";
							echo"<li>$ColorEndViSh - Color Endure Violet Shampoo</li>";	
						


					//	1. Connect to database
			$host="localhost";
			$dbUsername="MIS4153";
			$dbPassword="pirates4thewin";
			$dbName="teamtrilogy";

			$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
			if(mysqli_connect_errno()){
				printf("Connect failed: %\n", mysqli_connect_error()); 
			} else {

				//2. Send query to database: mysqli_query()
					$sql = "INSERT INTO joicoproducts (BodyLuxCond, BodyLuxSh, ColorEndCond, ColorEndSh, ColorEndViCond, ColorEndViSh) values ('$BodyLuxCond', '$BodyLuxSh', '$ColorEndCond', '$ColorEndSh', '$ColorEndViCond', '$ColorEndViSh')";
					//echo $sql;
					$JoicoArray = mysqli_query($connection, $sql);
					$lastID =mysqli_insert_id($connection);
					
					

					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
				
					?>	
				
					<div align="center">
				<br><br>	<strong><h1>What would you like to do next?</h1><strong>
					</div>
			
			
				
					
					<a href="addinventory.php" class="button">Add More Inventory</a><br>
							<br><a href="joicoinventory.php" class="button">View Joico Inventory</a><br>
						
					
				
				
				</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>