<?php
session_start();
?>

<!DOCTYPE HTML>
<!--
	Twenty by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
html>
	<head>
		<title>NTS Inventory Manager</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="right-sidebar is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1 id="logo">Add New Olaplex Inventory</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
				</header>

			<!-- Main -->
			<section id="main" class="container">
					
					
					
					
					
					<div class="box" align="center">
					<h2>Input <strong>Olaplex</strong> Product Quantities Below</h2>
					<form method="POST" action="OlaplexAddProcessing.php">
						
						Olaplex #1: <input type="number" min=0 max=12 name="OlaOne"><br>
						<br>Olaplex #2: <input type="number" min=0 max=12 name="OlaTwo"><br>
						<br>Olaplex #3: <input type="number" min=0 max=12 name="OlaThree"><br>
						<br>Olaplex #4: <input type="number" min=0 max=12 name="OlaFour"><br>
						<br>Olaplex #5: <input type="number" min=0 max=12 name="OlaFive"><br>
						<br>Olaplex #6: <input type="number" min=0 max=12 name="OlaSix"><br>
				
					
						<br><input type="Submit" name="Submit" value="Submit">
						
						
						</form>	
						
				

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>