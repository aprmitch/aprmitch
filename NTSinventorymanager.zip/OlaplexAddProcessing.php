<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>Olaplex Inventory Added
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Olaplex Inventory Added</h1>
					<nav id="nav">
						<ul>
						<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
			
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<strong><h2>Olaplex Inventory Added</h2></strong>
					
					</header>
					
					<div class="box">
						
						<?php
							$OlaOne=$_POST["OlaOne"];
							$OlaTwo=$_POST["OlaTwo"];
							$OlaThree=$_POST["OlaThree"];
							$OlaFour=$_POST["OlaFour"];
							$OlaFive=$_POST["OlaFive"];
							$OlaSix=$_POST["OlaSix"];
						
						
						
						
							echo "You added the following Olaplex products to inventory: ";
							
							echo "<li>$OlaOne - Olaplex #1</li>";
							echo"<li>$OlaTwo - Olaplex #2</li>";
							echo"<li>$OlaThree - Olaplex #3</li>";
							echo"<li>$OlaFour - Olaplex #4</li>";
							echo"<li>$OlaFive - Olaplex #5</li>";
							echo"<li>$OlaSix - Olaplex #6</li>";	
				//1. Connect to database
				$host="localhost";
				$dbUsername="MIS4153";
				$dbPassword="pirates4thewin";
				$dbName="teamtrilogy";
	
				$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
				if(mysqli_connect_errno()){
					printf("Connect failed: %\n", mysqli_connect_error());
				} else {

			//2. Send query to database: mysqli_query()
			$sql = "Insert into olaplex (OlaOne, OlaTwo, OlaThree, OlaFour, OlaFive, OlaSix) values ('$OlaOne', '$OlaTwo', '$OlaThree', '$OlaFour', '$OlaFive', '$OlaSix')";
			//echo $sql;
			$OlaplexArray = mysqli_query($connection, $sql);
			$lastID =mysqli_insert_id($connection);					


					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
				
					?>	
				
					<div align="center">
				<br><br>	<strong><h1>What would you like to do next?</h1><strong>
					</div>
			
			
				
					
					<a href="addinventory.php" class="button">Add More Inventory</a><br>
							<br><a href="olaplexinventory.php" class="button">View Olaplex Inventory</a><br>
						
						
					
				
				
				</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>