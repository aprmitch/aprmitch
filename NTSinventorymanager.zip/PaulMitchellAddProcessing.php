<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>Paul Mitchell Inventory Update
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Paul Mitchell Inventory Update</h1>
					<nav id="nav">
						
						<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
			
						
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<strong><h2>Paul Mitchell Inventory Added</h2></strong>
					
					</header>
					
					<div class="box">
						
						<?php
							$AwapuhiSh=$_POST["AwapuhiSh"];
							$ShOne=$_POST["ShOne"];
							$ShTwo=$_POST["ShTwo"];
							$ShThree=$_POST["ShThree"];
							$TheCond=$_POST["TheCond"];
						
						
							echo "You added the following Paul Mitchell products to inventory: ";
							
							echo "<li>$AwapuhiSh - Awapuhi Shampoo</li>";
							echo"<li>$ShOne - Shampoo One</li>";
							echo"<li>$ShTwo - Shampoo Two</li>";
							echo"<li>$ShThree - Shampoo Three</li>";
							echo"<li>$TheCond - The Conditioner</li>";
								
						


					//	1. Connect to database
			$host="localhost";
			$dbUsername="MIS4153";
			$dbPassword="pirates4thewin";
			$dbName="teamtrilogy";

			$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
			if(mysqli_connect_errno()){
				printf("Connect failed: %\n", mysqli_connect_error()); 
			} else {

					//2. Send query to database: mysqli_query()
					$sql = "INSERT INTO paulmitchell (AwapuhiSh, ShOne, ShTwo, ShThree, TheCond) values ('$AwapuhiSh', '$ShOne', '$ShTwo', '$ShThree', '$TheCond')";
					//echo $sql;
					$PaulMitchellArray = mysqli_query($connection, $sql);
					$lastID =mysqli_insert_id($connection);
					
					

					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
				
					?>	
				
					<div align="center">
				<br><br>	<strong><h1>What would you like to do next?</h1><strong>
					</div>
			
			
				
					
					<a href="addinventory.php" class="button">Add More Inventory</a><br>
							<br><a href="paulmitchellinventory.php" class="button">View Paul Mitchell Inventory</a><br>
						
						
					
				
				
				</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>