<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
			<header id="header">
					<h1>Redken Inventory Update</h1>
					<nav id="nav">
						
						<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
			
						
					</nav>
				</header>
			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<div align="center">
						<strong><h2>Redken Inventory Added</h2></strong>
					
					</header>
					
					<div class="box">
				
						<?php
								
									$ExBleachSh=$_POST["ExBleachSh"];
									$ExCatRecon=$_POST["ExCatRecon"];
									$ExCond=$_POST["ExCond"];
									$ExLengthSh=$_POST["ExLengthSh"];
									$Fabricate03=$_POST["Fabricate03"];
									
									echo "You added the following Redken products to inventory: ";
							
									echo "<li>$ExBleachSh - Extreme Bleach Shampoo</li>";
									echo"<li>$ExCatRecon - Extreme Cat Reconstructor</li>";
									echo"<li>$ExCond - Extreme Conditioner</li>";
									echo"<li>$ExLengthSh - Extreme Length Shampoo</li>";
									echo"<li>$Fabricate03 - Fabricate 03</li>";
	//1. Connect to database
	$host="localhost";
	$dbUsername="MIS4153";
	$dbPassword="pirates4thewin";
	$dbName="teamtrilogy";

	$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
	if(mysqli_connect_errno()){
		printf("Connect failed: %\n", mysqli_connect_error());
	} else {

//2. Send query to database: mysqli_query()
$sql = "Insert into redkenproducts (ExBleachSh, ExCatRecon, ExCond, ExLengthSh, Fabricate03) values ('$ExBleachSh', '$ExCatRecon', '$ExCond', '$ExLengthSh', '$Fabricate03')";
//echo $sql;
$RedkenArray = mysqli_query($connection, $sql);
$lastID =mysqli_insert_id($connection);	
	
	



					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
					
					
					?>
					<div align="center">
					<br><br>	<strong><h1>What would you like to do next?</h1><strong>
					</div>
			
							<a href="addinventory.php" class="button">Add More Inventory</a><br>
							<br><a href="redkeninventory.php" class="button">View Redken Inventory</a><br>
							
				
				</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>