<!DOCTYPE HTML>
<!--
	Superslow Workout App
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Superslow Workout App</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1>Superslow</h1>
					<nav id="nav">
						<ul>
							<li></li>
			
							<li><a href="index.php" class="button">Home</a></li>
							<li><a href="WorkoutList.php" class="button">Login</a></li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
					<h2>Superslow Workout App</h2>
					<p>Track your workout progress</p>
					<ul class="actions special">
						<li><a href="WorkoutList.php" class="button primary">Login</a></li>
						
					</ul>
				</section>

			<!-- Main -->
				<section id="main" class="container">

				</section>

		

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>