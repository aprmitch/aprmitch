
<?php
session_start();
?>


<!DOCTYPE HTML>

<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Update Joico Inventory</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
			
			<section id="main" class="container" align="center">
					<header>
						<h2>Current Joico Inventory</h2>
					
					</header>
					
					<div class="box" >
					<form method="POST" action="joicoupdateprocessing.php">
					<table>
			
			<strong><tr><th>Body Luxe Cond.</th><th>Body Luxe Sh.</th><th>Color Endure Cond.</th><th>Color Endure Sh.</th><th>Color Endure Violet Cond.</th><th>Color Endure Violet Sh.</th></tr></strong>
					<?php
	//1. Connect to database: mysqli_connect()
	$host="localhost";
	$dbUsername="MIS4153";
	$dbPassword="pirates4thewin";
	$dbName="teamtrilogy";
	
	$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
	if(mysqli_connect_errno()){
	printf("Connect failed: %\n", mysqli_connect_error());
	} else {
	
	
	//2. Send query to database: mysqli_query()
	$sql = "SELECT * FROM joicoproducts ORDER BY ID DESC LIMIT 1";
	$JoicoArray = mysqli_query($connection, $sql);
	
	
			//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
			while ($joicoproducts=mysqli_fetch_assoc($JoicoArray)){
				echo "<tr>";
				echo "<td>". $joicoproducts["BodyLuxCond"] . "</td>";
				echo "<td>". $joicoproducts["BodyLuxSh"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndCond"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndSh"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndViCond"] . "</td>";
				echo "<td>". $joicoproducts["ColorEndViSh"] . "</td>";
				
				echo "</tr>";
			}
			
	
				//4. Release returned data: mysqli_free_result()
			mysqli_free_result($JoicoArray);
	}
					//5. Close database connection: mysqli_close()
					mysqli_close($connection);
			
					?>
				</table>
				<h2>Update Product Quantities Below</h2>
				<?php					

//1. Connect to database: mysqli_connect()
$host="localhost";
$dbUsername="MIS4153";
$dbPassword="pirates4thewin";
$dbName="teamtrilogy";

$connection = mysqli_connect($host,$dbUsername,$dbPassword,$dbName);
if(mysqli_connect_errno()){
printf("Connect failed: %\n", mysqli_connect_error());
} else {


//2. Send query to database: mysqli_query()
$sql = "SELECT * FROM joicoproducts WHERE ID='" . $_GET["ID"] . "'";
$JoicoArray = mysqli_query($connection, $sql);


//3. Use the returned data

$joicoproducts=mysqli_fetch_assoc($JoicoArray);

echo "Joico Body Luxe Conditioner: <input type='number' min=0 max=12 name='BodyLuxCond' value='" . $joicoproducts["BodyLuxCond"] . "'><br>";
echo "<br>Joico Body Luxe Shampoo: <input type='number' min=0 max=12 name='BodyLuxSh' value='" . $joicoproducts["BodyLuxSh"] . "'><br>";
echo "<br>Joico Color Endure Conditioner: <input type='number' min=0 max=12 name='ColorEndCond' value='" . $joicoproducts["ColorEndCond"] . "'><br>";
echo "<br>Joico Color Endure Shampoo: <input type='number' min=0 max=12 name='ColorEndSh' value='" . $joicoproducts["ColorEndSh"] . "'><br>";
echo "<br>Joico Color Endure Violet Conditioner: <input type='number' min=0 max=12 name='ColorEndViCond' value='" . $joicoproducts["ColorEndViCond"] . "'><br>";
echo "<br>Joico Color Endure Violet Shampoo: <input type='number' min=0 max=12 name='ColorEndViSh' value='" . $joicoproducts["ColorEndViSh"] . "'><br>";
echo "<br><input type='hidden' name='ID' value='" . $_GET['ID'] . "'>";


//4. Release the returned data
mysqli_free_result($JoicoArray);
}

//5. Close the connection
mysqli_close($connection);

?>	
<input type="submit" name="submit" value="Submit">

						</form>	
					
						
					</div>
				</section>

			<!-- Footer -->
				
		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>