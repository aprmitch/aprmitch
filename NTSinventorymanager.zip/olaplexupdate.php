<?php
session_start();
?>


<!DOCTYPE HTML>

<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Update Olaplex Inventory</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
			
					<section id="main" class="container" align="center">
					<header>
						<h2>Current Olaplex Inventory</h2>
					
					</header>
					
					<div class="box">
					<form method="POST" action="olaplexupdateprocessing.php">
					<table>
			
			<strong><tr><th>Olaplex #1</th><th>Olaplex #2</th><th>Olaplex #3</th><th>Olaplex #4</th><th>Olaplex #5</th><th>Olaplex #6</th></tr></strong>
					<?php
	//1. Connect to database: mysqli_connect()
	$host="localhost";
	$dbUsername="MIS4153";
	$dbPassword="pirates4thewin";
	$dbName="teamtrilogy";
	
	$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
	if(mysqli_connect_errno()){
	printf("Connect failed: %\n", mysqli_connect_error());
	} else {
	
	
	//2. Send query to database: mysqli_query()
	$sql = "SELECT * FROM olaplex ORDER BY ID DESC LIMIT 1";
	$OlaplexArray = mysqli_query($connection, $sql);
	
	
			//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
			while ($olaplex=mysqli_fetch_assoc($OlaplexArray)){
				echo "<tr>";
				echo "<td>". $olaplex["OlaOne"] . "</td>";
				echo "<td>". $olaplex["OlaTwo"] . "</td>";
				echo "<td>". $olaplex["OlaThree"] . "</td>";
				echo "<td>". $olaplex["OlaFour"] . "</td>";
				echo "<td>". $olaplex["OlaFive"] . "</td>";
				echo "<td>". $olaplex["OlaSix"] . "</td>";
				
				echo "</tr>";
			}
			
	
				//4. Release returned data: mysqli_free_result()
			mysqli_free_result($OlaplexArray);
	}
					//5. Close database connection: mysqli_close()
					mysqli_close($connection);
			
					?>
				</table>
				<h2>Update Product Quantities Below</h2>
						<?php

//1. Connect to database: mysqli_connect()
$host="localhost";
$dbUsername="MIS4153";
$dbPassword="pirates4thewin";
$dbName="teamtrilogy";

$connection = mysqli_connect($host,$dbUsername,$dbPassword,$dbName);
if(mysqli_connect_errno()){
printf("Connect failed: %\n", mysqli_connect_error());
} else {


//2. Send query to database: mysqli_query()
$sql = "SELECT * FROM olaplex WHERE ID='" . $_GET["ID"] . "'";
$OlaplexArray = mysqli_query($connection, $sql);


//3. Use the returned data

$olaplex=mysqli_fetch_assoc($OlaplexArray);

echo "Olaplex #1: <input type='number' min=0 max=12 name='OlaOne' value='" . $olaplex["OlaOne"] . "'><br>";
echo "<br>Olaplex #2: <input type='number' min=0 max=12 name='OlaTwo' value='" . $olaplex["OlaTwo"] . "'><br>";
echo "<br>Olaplex #3: <input type='number' min=0 max=12 name='OlaThree' value='" . $olaplex["OlaThree"] . "'><br>";
echo "<br>Olaplex #4: <input type='number' min=0 max=12 name='OlaFour' value='" . $olaplex["OlaFour"] . "'><br>";
echo "<br>Olaplex #5: <input type='number' min=0 max=12 name='OlaFive' value='" . $olaplex["OlaFive"] . "'><br>";
echo "<br>Olaplex #6: <input type='number' min=0 max=12 name='OlaSix' value='" . $olaplex["OlaSix"] . "'><br>";
echo "<br><input type='hidden' name='ID' value='" . $_GET['ID'] . "'>";


//4. Release the returned data
mysqli_free_result($OlaplexArray);
}

//5. Close the connection
mysqli_close($connection);

?>	
<input type="submit" name="submit" value="Submit">

						</form>	
					
						
					</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>