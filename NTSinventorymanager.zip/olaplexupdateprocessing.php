<?php
session_start();
?>



<!DOCTYPE HTML>


<html>
	<head>
		<title>NTS Inventory Manager
	</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1>Olaplex Inventory Update Processed</h1>
					<nav id="nav">
					<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<section id="main" class="container" align="center">
					<header>
						<strong><h2>Olaplex Inventory Updated</h2></strong>
					
					</header>
					
					<div class="box">
						
						<?php
									
							$OlaOne=$_POST["OlaOne"];
							$OlaTwo=$_POST["OlaTwo"];
							$OlaThree=$_POST["OlaThree"];
							$OlaFour=$_POST["OlaFour"];
							$OlaFive=$_POST["OlaFive"];
							$OlaSix=$_POST["OlaSix"];

									//1. Connect to database
									$host="localhost";
									$dbUsername="MIS4153";
									$dbPassword="pirates4thewin";
									$dbName="teamtrilogy";
						
									$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
									if(mysqli_connect_errno()){
										printf("Connect failed: %\n", mysqli_connect_error());
									} else {

					//2. Send query to database: mysqli_query()
					$sql = "Update olaplex SET OlaOne='$OlaOne', OlaTwo='$OlaTwo', OlaThree='$OlaThree', OlaFour='$OlaFour', OlaFive='$OlaFive', OlaSix='$OlaSix'";
					//echo $sql;
					$OlaplexArray = mysqli_query($connection, $sql);
					$lastID =mysqli_insert_id($connection);
					
					

					//3. Use the returned data - not using this page
					//4. Release returned date - not using this page
					//5. Close the connection
					}
					mysqli_close($connection);
					
					
					?>	
							<table>
			
			<tr><th>Olaplex #1</th><th>Olaplex #2</th><th>Olaplex #3</th><th>Olaplex #4</th><th>Olaplex #5</th><th>Olaplex #6</th></tr>
							<?php
			//1. Connect to database: mysqli_connect()
			$host="localhost";
			$dbUsername="MIS4153";
			$dbPassword="pirates4thewin";
			$dbName="teamtrilogy";
			
			$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);
			if(mysqli_connect_errno()){
			printf("Connect failed: %\n", mysqli_connect_error());
			} else {
			
			
			//2. Send query to database: mysqli_query()
			$sql = "SELECT * FROM olaplex ORDER BY ID DESC LIMIT 1";
			$OlaplexArray = mysqli_query($connection, $sql);
			
			
					//3. Use returned data: mysqli_fetch_row(), mysqli_fetch_array(), or mysqli_fetch_assoc()
					while ($olaplex=mysqli_fetch_assoc($OlaplexArray)){
						echo "<tr>";
						echo "<td>". $olaplex["OlaOne"] . "</td>";
						echo "<td>". $olaplex["OlaTwo"] . "</td>";
						echo "<td>". $olaplex["OlaThree"] . "</td>";
						echo "<td>". $olaplex["OlaFour"] . "</td>";
						echo "<td>". $olaplex["OlaFive"] . "</td>";
						echo "<td>". $olaplex["OlaSix"] . "</td>";
						
						
						echo "</tr>";
					}
					
			
						//4. Release returned data: mysqli_free_result()
					mysqli_free_result($OlaplexArray);
			}
							//5. Close database connection: mysqli_close()
							mysqli_close($connection);
					
							?>
						</table>
				
					<div align="center">
					<br><br>	<strong><h1>What would you like to do next?</h1><strong>
					
			
			
				
					<a href="addinventory.php" class="button">Add Inventory</a><br>
							<br><a href="redkeninventory.php" class="button">View Olaplex Inventory</a><br>
				</div>
					
				
				
				</div>	
					
					
						
					</div>
				</section>

			<!-- Footer -->
				

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>