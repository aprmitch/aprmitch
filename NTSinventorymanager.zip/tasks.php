<?php
session_start();
$username = "aprilmitchell";
$password = "1234";

if($username==$_POST["username"] && $password==$_POST["password"]){
	$_SESSION["username"] = $username;
		header("Location: WorkoutList.php");
} else {
	unset($_SESSION["username"]);
}

?>

<!DOCTYPE HTML>

<html>
	<head>
		<title>NTS Inventory Manager</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1>Welcome to Nikki Taylor Salon</h1>
					
					<nav id="nav">
						<ul>
							
			
						<ul>
							<li><a href="tasks.php" class="button primary">Home</a></li>
							
							<li><a href="logout.php" class="button primary">Logout</a></li>
						</ul>
						</ul>
					</nav>
				</header>

			<!-- Banner --> 

			<div class box>
				<section id="banner">
					<h2>Welcome to Nikki Taylor Salon Inventory Manager</h2>
					
					<p> What would you like to do?</p>
					
					
					
						<ul>
					
							<br><a href="addinventory.php" class="button">Input New Inventory</a><br>
							<br><a href="modifyinventory.php" class="button">Modify Quantities</a><br>
							<br><a href="viewinventory.php" class="button">View Product Inventory</a><br>
							<br><a href="inventoryproductlist.php" class="button">Vendor Access</a><br>
						</ul>
					
				
				</section>
					</div>
			<!-- Main -->
				<section id="main" class="container">

				</section>

		

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>